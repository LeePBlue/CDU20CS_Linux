#include"enterMark.h"
using namespace std;
enterMark::enterMark()
{
    chineseMark = 0;
    englishMark = 0;
    mathMark    = 0;
}
enterMark::~enterMark()
{
    cout << "ending" << endl;
}

void enterMark::addMark()
{ 
  cout << "please enter student name"<<endl;
  cin >> enterMark::stu ;
  cout << "please enter chinese mark"<<endl;
  cin >> enterMark::chineseMark;
  cout << "please enter english mark"<<endl;
  cin >> enterMark::englishMark;
  cout << "please enter math mark"<<endl;
  cin >> enterMark::mathMark;
}
