#include"countMark.h"
using namespace std;
countMark::countMark()
{
}
countMark::~countMark()
{
    cout<<"ending"<<endl;
}

double countMark::sumMark(double ch,double en,double ma)
{
    int sumScore ;
    sumScore = (ch + en + ma);
    return sumScore;
}