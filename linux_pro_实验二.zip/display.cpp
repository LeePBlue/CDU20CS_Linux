#include<iostream>
using namespace std;
/// @brief 
void display(string a,int b){
   cout<<"student name is"<<" "<<a<<endl;
   cout<<a<<" "<<"summarks are"<<" "<<b<<endl;
   }
// void display(auto  *d,auto *e)
// {
//     cout<<mar->stu << " " << "chinese is" <<" "<<mar->chineseMark<<endl ;
//     cout<<mar->stu << " " << "average score is"<<" "<<countM->averageMark(mar->chineseMark,mar->englishMark,mar->mathMark)<<endl;
// }