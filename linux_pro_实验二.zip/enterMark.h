#include<iostream>
using namespace std;

class enterMark{
public:
    enterMark();
    ~enterMark();
    void addMark();
    string stu;
    double chineseMark;
    double englishMark;
    double mathMark;
    

};