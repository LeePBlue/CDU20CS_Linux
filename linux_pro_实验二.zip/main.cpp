#include<iostream>
#include<string>
#include"enterMark.h"
#include"countMark.h"
#include"display.h"
using namespace std;

int main(){
    int sum = 0;
    enterMark *mar = new enterMark();
    countMark *countM = new countMark();
    mar->addMark();
    display(mar->stu,countM->sumMark(mar->chineseMark,mar->englishMark,mar->mathMark));
    return 0;
}
