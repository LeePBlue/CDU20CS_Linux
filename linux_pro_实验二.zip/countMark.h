#include<iostream>
using namespace std;

class countMark{
public:
    countMark();
    ~countMark();
    double sumMark(double ,double,double);
};